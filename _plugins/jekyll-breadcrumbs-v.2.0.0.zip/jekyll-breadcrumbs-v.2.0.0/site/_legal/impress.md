---
title: Impress
---
# Impress
This is just a single **collection** page to demonstrate breadrumbs (footer) on collections.  
