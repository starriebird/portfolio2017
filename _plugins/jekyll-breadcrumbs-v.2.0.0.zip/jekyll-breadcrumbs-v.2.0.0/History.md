# Change Log

## alekuel
multiple faster than liquid (test ergebisse) zeigen
- fix some levels are missing in multiple subdirectories
- Dropped translation support
- Example site
- Testig via Travis
_site irgendwo als demo publizieren.

potential isue may not work with baseurl, if somebody has a problem please report
